// Smooth scrolling or basic scripts can go here
console.log("Script loaded successfully!");
